module.exports={
    x:10
}