// const http = require('http');
// http.createServer((req,res)=>{
//     res.write("Hello World");
//     res.end();
// }).listen(3500)


var colors = require('colors/safe');

console.log(colors.rainbow('Run hbhbdhb'));