let api = fetch("https://jsonplaceholder.typicode.com/users")
var names = document.getElementById("api");

api.then((d)=>{
    return d.json()
}).then((actualdata)=>{
    names.innerHTML = actualdata[0].name;
})

