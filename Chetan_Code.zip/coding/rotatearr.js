let arr = [1,2,3];
k=3;
function swap(a1,s,e){
    while(s<=e){
    let temp = a1[s];
    a1[s] = a1[e];
    a1[e] = temp
    s++;
    e--;
    }
    
}
function rotateArr(nums,k){
    
    let end = nums.length-1;
    k=k%end;
    let i=0
    // if(arr.length==1){
    //     arr[i] == arr[i]
    //     console.log(arr);
    // }
    swap(nums,0,end-k)
    swap(nums,end-k+1,end)
    swap(nums,0,end)
    console.log(nums);
}


rotateArr(arr,k)

