let obj = {
    name: "chetan",
    age: "21",
    proffesion: "Engineer"
}

console.log(obj);
let a = {
    surname: "Divekar",
    skill: "Developer"
}

obj.__proto__ = a;

console.log(obj.skill);