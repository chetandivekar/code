let arr = [9,6,4,2,3,5,7,0,1,7,0]

let map = new Map();

for(let i in arr){
    if(!map[arr[i]]){
        map[arr[i]] = 1;
    }
    else{
        map[arr[i]]+=1;
    }
}


console.log(map[4]);