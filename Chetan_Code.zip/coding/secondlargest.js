let n = 5;
while(n--){
    console.log(5);
}