// let arr = [1,2,3,4,5];
// let key = 5;
// function searchinrotate(arr,key){
//     let s=0;
//     let e=arr.length-1;
    
//     while(s<=e){
//         let mid = Math.floor((s+e)/2)
//         if(key==arr[mid]){
//             return mid;
//         }
//         else if(key>arr[mid]){
//             s = mid+1;
//         }
//         else{
//             e = mid-1;
//         }
//     }
// }

// console.log(searchinrotate(arr,key));


let arr = [3,4,5,1,2];
let key = 5;

function searchinrotatedarry(arr,key){
    let max = 0;
    let peak;
    for(let i=0 ; i<arr.length; i++){
        if(arr[i]>max){
            max = arr[i];
            peak = i;
        }
        
    }
    if(key<max){
        let s = peak+1;
        let e = arr.length-1;
        while(s<=e){
            let mid = Math.floor((s+e)/2);
            if(key==arr[mid]){
                return mid;
            }
            else if(key>arr[mid]){
                s=mid+1;
            }
            else{
                e=mid-1
            }
        }


    }
    else if(key==arr[peak]){
        return peak;
    }
    else{
      
        let s= 0;
        let e = peak-1;
        while(s<=e){
            let mid = Math.floor((s+e)/2);
            if(key==arr[mid]){
                return mid;
            }
            else if(key>arr[mid]){
                s=mid+1;
            }
            else{
                e=mid-1
            }
        }
    }
    return -1
}

console.log(searchinrotatedarry(arr,key))
