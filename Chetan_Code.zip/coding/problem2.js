let str = "teammeat";

let newarr = new Array(26).fill(0);
for(let i =0; i<str.length; i++){
    newarr[str.charCodeAt(i) - 97] += 1;
}
let arr2 = [];
for(let i=0; i<newarr.length; i++){
    if(newarr[i]>1){
        arr2.push(newarr[i])
    }
}
if(arr2.length==0){
    console.log(0);
}
else{
    let ans  = arr2.reduce(((total, num)=> {
        return Math.abs(total - num);
      }))
    console.log(ans);
}




