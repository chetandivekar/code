let arr = [1, 2, 9, 9, 9, 9, 4];
function maxOccurence(arr) {
  let hashMap = {};
  for (let i = 0; i < arr.length; i++) {
    if ((hashMap[arr[i]] = hashMap[arr[i]])) {
      hashMap[arr[i]] += 1;
    } else {
      hashMap[arr[i]] = 1;
    }
  }
  let max = 1;
  let index;
  for (let i in hashMap) {
    if (hashMap[i] > max) {
      max = hashMap[i];
      index = i;
    } else {
      index = arr[0];
    }
  }
  console.log(
    `the max occurence element is ${index} with the occurence of ${max}`
  );
}
maxOccurence(arr);
