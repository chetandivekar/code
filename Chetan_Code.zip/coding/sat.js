
// console.log(a);
// let arr = [1,2,3,4,5];
// function addElemnts(callback){
//     setTimeout(()=>{
//         arr.push(6);
//        callback()
    
//     },2000)

// }
// function printArray(){
//     console.log(arr);
// }

// addElemnts(printArray);



// let a =5;

// function log(data){
//     console.log(data);
// }


// log(a)


// let abc =5;


// loga(abc);

// function loga(abc){
//     console.log(abc);
// }


// let nilesh = require("os");

// console.log(nilesh.platform());




// setTimeout(()=>{
//     console.log("a");
// },5000)

// setTimeout(()=>{
//     console.log("b");
// },2000)


function name2(){
    return new Promise((resolve)=>{
        setTimeout(()=>{
            resolve("Chetan");
        },3000)
    })
   
}

 function myname(data){
    console.log("chetan" , data);
} 

name2().then(myname)



// setTimeout(()=>{
//     console.log("c");
// },3000)

// console.log("z");