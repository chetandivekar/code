let passChar = "abcdefghijklmnopqrstuvwxyz";
let passNum = "0123456789";
let passSym = "!@#$%&*_"

let digit = 4;
let numeric = false;
let symbol = true;

let result = (pass, digit , numeric , symbol ,passnum , passsym) => {
  let password = "";

  if(numeric==false && symbol==false){
    for (let i = 0; i < digit; i++) {
        const passwordLength = pass.length;
        let randomChar = Math.floor(Math.random() * passwordLength);
        password += pass[randomChar];
      }
      return password
  }

  else if(numeric==true){
    for (let i = 0; i < (digit / 2); i++) {
        const passwordLength = pass.length;
        let randomChar = Math.floor(Math.random() * passwordLength);
        password += pass[randomChar];
        
        
      }
      if(digit%2==0){
        for(let i=0; i<(digit/2); i++){
            const numericLength = passnum.length
            let randomNum = Math.floor(Math.random() * numericLength);
            password += passnum[randomNum]
          }
          return password
      }
      else{
        for(let i=0; i<(digit/2)-1; i++){
            const numericLength = passnum.length
            let randomNum = Math.floor(Math.random() * numericLength);
            password += passnum[randomNum]
          }
          return password
      }
      
  }

  else if(symbol==true){
    for (let i = 0; i < (digit / 2); i++) {
        const passwordLength = pass.length;
        let randomChar = Math.floor(Math.random() * passwordLength);
        password += pass[randomChar];
       
        
      }

      for(let i=0; i<(digit/2);i++){
        const symbolLength = passsym.length;
        let randomSym = Math.floor(Math.random() * symbolLength);
        password += pass[randomSym];
        return password;
      }

      if(digit%2==0){
        for(let i=0; i<(digit/2); i++){
            const numericLength = passnum.length
            let randomNum = Math.floor(Math.random() * numericLength);
            password += passnum[randomNum]
          }
          return password
      }
      else{
        for(let i=0; i<(digit/2)-1; i++){
            const numericLength = passnum.length
            let randomNum = Math.floor(Math.random() * numericLength);
            password += passnum[randomNum]
          }
          return password
      }
      
    
  }
  
};

console.log(result(passChar, digit ,numeric, symbol, passNum ,passSym));
