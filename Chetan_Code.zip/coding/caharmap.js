let str= "abbabcabz";
let newarr = new Array(26).fill(0);
for(let i =0; i<str.length; i++){
    newarr[str.charCodeAt(i) - 97] += 1;
}

function toprint(arr, char){
    console.log(arr[char.charCodeAt(0)-97]);
}

toprint(newarr , "b");

