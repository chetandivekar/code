let oldPlayList = ["Airplane", "Mode","Astral", "traveling","Driving", "vocals","Nostalgic", "Journeys"];
let newPlaylist = [ "vocals","Nostalgic","traveling","Astral"];
let ans = new Set();
oldPlayList.forEach((e)=>{
    ans.add(e)
})

ans.forEach((e)=>{
    for(let i=0; i<ans.size; i++){
        if(e==newPlaylist[i]){
            ans.delete(newPlaylist[i])
        }
    }
})

ans.forEach((e)=>{
    console.log(e);
})
