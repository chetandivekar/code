
let myPromise = new Promise(function(myResolve, myReject) {
    let x = 0;
    
    if (x == 0) {
      myResolve();
    } else {
      myReject();
    }
  });

  function sum(){
    console.log("chetan");
  }
  function err(){
    console.log("error");
  }
  
 myPromise.then(sum).catch(err)