
// function names(){

//     return  new Promise((resolve, reject) => {
//         setTimeout(() => {
//             let names = "chetan";
//             resolve(names)
//         },2000);
//     })   
// }

// names().then((data)=>{
//     console.log(data) ;
// }, (error)=>{
//     console.log("erroe");
// });

function getEmogies(a){
    switch(a){
        case 'sunny':
            console.log("☀️");
            break
        case 'rainy':
            console.log("🌧️");
            break
        case 'cloudy':
            console.log("☁️");
            break
        default:
            console.log("No data found ");
    }
}

function getWeather(){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            let sunny = "sunny"
            let err = false;
            if(!err){
                resolve(sunny)
            }
            else{
                reject();
            }
        
        },2000)
    })
}

function onSuccess(){
    console.log("sucess");
}

function onFailuer(){
    console.log("error has occured");
}

getWeather().then(getEmogies).catch(onFailuer)
