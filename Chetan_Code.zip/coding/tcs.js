function countNumbersWithRepeatedDigits(n1, n2) {
  let count = 0;
  for (let i = n1; i <= n2; i++) {
    let digits = new Set();
    let num = i;
    while (num > 0) {
      let digit = num % 10;
      if (digits.has(digit)) {
        count++;
        break;
      } else {
        digits.add(digit);
      }
      num = Math.floor(num / 10);
    }
    console.log(digits);
  }
  
  return count;
 
}

let n1 = 101;
let n2 = 200;
let count = countNumbersWithRepeatedDigits(n1, n2);
console.log("Number of integers with repeated digits between", n1, "and", n2, "is", (n2-n1)+1-count);
