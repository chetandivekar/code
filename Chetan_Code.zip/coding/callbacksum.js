


// function addElements(arr , value , callback ,arr1){
//     setTimeout(()=>{
//         arr.push(value)
//         callback(arr1);
//     },3000)
// }

// function printArray(arr){
//     setTimeout(()=>{
//         console.log(arr);
//     },2000)
// }



// function addElements(arr , value){
// return new Promise((resolve ,reject)=>{
//     setTimeout(()=>{
//         arr.push(value)
//         let err = false;
//         if(!err){
//             resolve();
//         }
//         else{
//             reject();
//         }
//     },3000)
// })
// }

// function printArray(arr){
//     setTimeout(()=>{
//         console.log(arr);
//     },2000)
// }


// addElements(arr,7).then(()=>{
//     printArray(arr)
// });

// let obj = {
//     names:"chetan",
//     rollno:42,
//     Degree:"Btech"
// }

// for(let i in obj){
//     console.log(obj[i]);
// }
// console.log("--------------------------");
// for(let i in obj){
//     console.log(i);
// }

let arr = [
    {
        names:"chetan",
        rollno:42
    },
    {
        names:"bhushan",
        rollno:42
    },
    {
        names:"nilesh",
        rollno:42
    },
    {
        names:"yuvraj",
        rollno:42
    }
]

for(let i=0; i<arr.length; i++){
    console.log(arr[i].names);
}