// let k=2;
// n=4;
// for(let i=1; i<=n; i++){
//     console.log(k * (2 *k -1));
//     k+=2;
// }

let str = "chetan"
let arr = ["a","e","i","o","u"];

let p = str.replace(/[a,e,i,o,u]/g, '')
console.log(p);


function names(str,arr){
    for(let i=0; i<str.length; i++){
        for(let j=0; j<arr.length; j++){
            if(str[i]==arr[j]){
                let ans = str.replace(str[i] , '');
                return ans
            }
        }
    }
}

console.log(names(str,arr));