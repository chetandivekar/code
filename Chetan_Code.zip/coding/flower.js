let flowerbed = [0,0,1,0,0];
let n = 1;

var canPlaceFlowers = function(flowerbed, n) {
    for(let i=0; i<flowerbed.length;i++){
    if(flowerbed[i]==0){
        let prev = (i==0 || flowerbed[i-1]==0?0:1);
        let next = (i==flowerbed.length-1 || flowerbed[i+1]==0?0:1);
        if(prev==0 && next==0){
            flowerbed[i]=1;
            n--;
        }
    }
    }
    if(n<=0){
        return true;
    }
    else{
        return false;
    }
    
};

console.log(canPlaceFlowers(flowerbed,n))
console.log(flowerbed);