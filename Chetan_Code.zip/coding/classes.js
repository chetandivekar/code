class railWay {
    submit(){
        console.log(this.name, "ticket submitted");
    }
    cancel(){
        console.log(this.name, "ticket is cancelled");
    }
    name(name){
        this.name = name;
    }
}

let chetan = new railWay;
chetan.name("chetan")
chetan.submit()