const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '0d15ec7c87msheb96567e65c3901p16fb6ajsnb5d7e2f9b873',
		'X-RapidAPI-Host': 'open-weather13.p.rapidapi.com'
	}
};

// fetch('https://open-weather13.p.rapidapi.com/city/landon', options)
// 	.then(response => response.json())
// 	.then(response => console.log(response))

async function getWeather(){
    let data = await fetch('https://open-weather13.p.rapidapi.com/city/landon', options)
   let result = await data.json()
    console.log(result);
}


getWeather()

// async function getweatherInfo(){
//     let data  = await getWeather()
//     switch(data){
//         case 'sunny':
//             console.log("The day is sunny")
//             break;
//         case 'rainy':
//             console.log("The day is rainy")
//             break;
//         case 'foggy':
//             console.log("The day is foggy")
//             break;
//         default:
//             console.log("No data found");
//     }
// }

