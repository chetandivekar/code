let obj ={
    name:"chetan",
    rollno:"42",
    profession:"engineer"
}

let arr = [1,2,3,5]

for(let i of arr){
    console.log(i);
}