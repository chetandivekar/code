// let str = "abcdefghijklmnopqrstuvwxyz";
// let str2 = str.toUpperCase();

// let input = "ChetAn";
// let lowercase = 0;
// let uppercase = 0;

// for(let i=0; i<input.length; i++){
//     for(let j=0; j<str.length; j++){
//         if(input[i]==str[j]){
//             lowercase++
//         }
//     }
// }
// for(let i=0; i<input.length; i++){
//     for(let j=0; j<str2.length; j++){
//         if(input[i]==str2[j]){
//             uppercase++
//         }
//     }
// }
// console.log(`the input "${input}" contain ${lowercase} lowercase letters and ${uppercase} uppercase letters`);


let input = 'chetan';
let lw=0;

if(input[0]>='a' && input[0]<='z'){
    console.log(true);
}

for(let i=0; i<input; i++){
    if(input[i]>='a' && input[i]<='z'){
        lw+=1;
    }
}
console.log(lw);

