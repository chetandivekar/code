let arr1 = [1,2,3,4];
let arr2 = [9,14,26,30];
let mainarr = [];
function mergesort(arr1, arr2, mainarr){
    let k=0;
    let i = 0;
    let j = 0;
    while(arr1[i]<=arr1[arr1.length-1] || arr2[j]<=arr2[arr2.length-1]){
        if(arr1[i]<arr2[j]){
            mainarr[k++] = arr1[i++]
        }
        else{
            mainarr[k++] = arr2[j++]
        }
    } 
    while(arr1[i]>arr1[arr1.length]){
        mainarr[k++] = arr2[j]
    }

    while(arr2[j]>arr2[arr2.length]){
        mainarr[k++] = arr1[i]
    }
    return mainarr;

}

let ans = mergesort(arr1,arr2,mainarr)
console.log(ans);