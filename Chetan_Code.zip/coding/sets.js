
let ans = new Set();
console.log(ans.has(5)); 
