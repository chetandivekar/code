let arr = [1,2,2,2,2,1,11,1]
let map = {};
for(let i in arr){
    if(!map[arr[i]]){
        map[arr[i]] = 1;

    }
    else{
        map[arr[i]]+=1;
    }
}
