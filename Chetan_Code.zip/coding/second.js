let arr = [3,1,2,5,-1,-2,6,4,9];

function swap(arr, i, j){
    let temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}
for(let i =0; i<arr.length; i++){
    for(let j=i; j<arr.length; j++){
        if(arr[i]>arr[j]){
            swap(arr ,i ,j);
        }
    }
}

console.log(arr);
console.log(arr[arr.length-2]);