const obj = [
    {
        name: "chetan",
        age: 20
    },
    {
        name: "nilesh",
        age:50
    },
    {
        name:"bhushan",
        age:70
    }

]


let ans= obj.findIndex((item)=>{
    if(item.age===70){
        return item
    }
})

console.log(ans);

let sums = obj.reduce(function fun(acc , curr){
    return acc + curr.age
} , 0)

console.log(sums);