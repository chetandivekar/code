let arr1 = [400,567,890,765,987];
let arr2 = [[300,380], [800,1000]];

for(let i=0; i<arr2.length; i++){
    let count=0
    let l = arr2[i][0];
    let h = arr2[i][1];
    for(let j=0; j<arr1.length; j++){
        if(arr1[j]>=l && arr1[j]<=h){
            count++;
        }
    }
    console.log(count);
}