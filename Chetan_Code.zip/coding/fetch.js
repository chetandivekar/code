// const options = {
//   method: "GET",
//   headers: {
//     "X-RapidAPI-Key": "0d15ec7c87msheb96567e65c3901p16fb6ajsnb5d7e2f9b873",
//     "X-RapidAPI-Host": "moviesdatabase.p.rapidapi.com",
//   },
// };

let obj = {
  results: [
    {
      id: "tt0001702",
      primaryImage: null,
      titleType: {
        text: "Short",
        id: "short",
        isSeries: false,
        isEpisode: false,
        __typename: "TitleType",
      },
      titleText: {
        text: "The Indian Maiden's Lesson",
        __typename: "TitleText",
      },
      releaseYear: { year: 1911, endYear: null, __typename: "YearRange" },
      releaseDate: { day: 22, month: 4, year: 1911, __typename: "ReleaseDate" },
    },
    {
      id: "tt0001856",
      primaryImage: {
        id: "rm970923264",
        width: 800,
        height: 597,
        url: "https://m.media-amazon.com/images/M/MV5BYmVhNGZlZTEtNjFmMS00MjEyLThkZmMtMTIwZjRjNzFkYjU3XkEyXkFqcGdeQXVyMDUyOTUyNQ@@._V1_.jpg",
        caption: {
          plainText:
            "Edwin August and Dorothy West in The Revenue Man and the Girl (1911)",
          __typename: "Markdown",
        },
        __typename: "Image",
      },
      titleType: {
        text: "Short",
        id: "short",
        isSeries: false,
        isEpisode: false,
        __typename: "TitleType",
      },
      titleText: {
        text: "The Revenue Man and the Girl",
        __typename: "TitleText",
      },
      releaseYear: { year: 1911, endYear: null, __typename: "YearRange" },
      releaseDate: { day: 25, month: 9, year: 1911, __typename: "ReleaseDate" },
    },
  ],
};

    let str = "";
    let ans = document.querySelector(".row");
   
    for (let i of obj.results) {
    str = str + `<div class="card container" style="width: 18rem;">
    <img class="card-img-top" src="" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${i.titleText.text}</h5>
      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      <a href="#" class="btn btn-primary">${i.primaryImage}</a>
    </div>
  </div>`
  ans.innerHTML = str;

  
  }

  console.log(obj.results);