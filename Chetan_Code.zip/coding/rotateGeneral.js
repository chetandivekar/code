let arr = [1,2];
let k = 10;

function rotateArr(arr,k){
    
    let len = arr.length-1;
    k=k%arr.length
    let newarr = [];
    for(let i=len-k+1; i<=len; i++){
        newarr.push(arr[i])
    }
    for(let i=0; i<=len-k; i++){
        newarr.push(arr[i])
    }
    console.log(newarr);
}

rotateArr(arr,k)
