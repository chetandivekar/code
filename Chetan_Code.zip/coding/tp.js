let count = 0;
let arr = {};

for(let i=11; i<=11; i++){
    let currentNumber = i;
    while (currentNumber >= 1) {
        let rem = Math.floor(currentNumber % 10);
        if (!arr[rem]) {
          arr[rem] = 1;
        } else {
          arr[rem] += 1;
          count++;
        }
        currentNumber = Math.floor(currentNumber / 10);
      }
      arr = {}
}

console.log(arr);
console.log(count);
