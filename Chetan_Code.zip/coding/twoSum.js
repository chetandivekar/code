let arr = [1,4,3,2,5]
let target = 9

//return [1,2] => 2+6 = 8

// Bruteforce methode:

// function twoSum(arr, target){
//     for(let i=0; i<arr.length; i++){
//         for(let j=i+1; j<arr.length; j++){
//             if(arr[i]+arr[j]==target){
//                 return [i, j]
//             }
//         }
//     }
//     return -1;
// }

// console.log(twoSum(arr,target));

//optimized methode:

function twoSum(nums,target){
    let hashMap = {};
    for(let i=0; i<nums.length; i++){
        // arr = [4,2,3]
        let currentValue = nums[i]; // 4; --2
        let neededValue = target - currentValue; //6-4 =2 -- 6-2 ==4
        let index2 = hashMap[neededValue]; //index2 = hashMap[2]
        if(index2!=null){
            return [index2,i]
        }
        else{
            hashMap[currentValue] = i // hashMap[4] = 0; --hashmap[2] = 1
        }

    }
}

console.log(twoSum(arr,target));