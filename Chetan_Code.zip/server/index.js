const Users = [
  {
    name: "chetan",
    age: 20,
  },
  {
    name: "nilesh",
    age: 50,
  },
  {
    name: "bhushan",
    age: 70,
  },
];

const http = require("http");
const server = http.createServer(function (request, response) {
  let paths = request.url.split("/");
  console.log(paths);
  if (request.method === "GET" && paths[1] === "users" && paths.length === 2) {
    response.write(JSON.stringify(Users));
  } else if (request.method === "POST" && paths[1] === "users") {
    response.statusCode = 201;
    response.write("User data created. ");

    let data = "";

    request.on("data", function (chunk) {
      data += chunk;
    });

    request.on("end", function () {
      let obj = JSON.parse(data.toString());
      console.log(obj);
    });
  } else if (request.method === "GET" && paths[1] === "users" && paths[2]) {
    const idx = paths[2];
    const user = Users[idx];
    if (user) {
      response.write(JSON.stringify(user));
    } else {
      response.write("Not Found");
    }
  } else {
    response.write("Not Found");
  }
  response.end();
});

server.listen(3001, function () {
  console.log("server is running on the port localhost:3000");
});
