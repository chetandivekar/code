const express = require("express");
const app = express();
const fs = require("fs");
const todoRouter = require("./routes/todos.router.js")

app.use(express.json());

function readData() {
  return new Promise((resolve, reject) => {
    fs.readFile("data.json", "utf8", (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(JSON.parse(data.toString()));
      }
    });
  });
}

function writeData(data) {
  return new Promise((resolve, reject) => {
    fs.writeFile("data.json", JSON.stringify(data), "utf8", (err) => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}
app.use("/todos", todoRouter.todoRouter)

app.get("/todos", (req, res) => {
  readData()
    .then((data) => {
      return res.status(200).json({
        message: "All todos fetched",
        data: data,
        error: null,
      });
    })
    .catch((err) => {
      return res.status(500).json({
        message: "Error while fetching todos",
        data: null,
        error: err,
      });
    });
});

app.post("/todos", (req, res) => {
  readData()
    .then((data) => {
      const newData = req.body;
      data.push(newData);
      return writeData(data);
    })
    .then(() => {
      return res.status(200).json({
        message: "Data added successfully",
        error: null,
      });
    })
    .catch((err) => {
      return res.status(500).json({
        message: "Error while adding data",
        error: err,
      });
    });
});

app.listen(3000, () => {
  console.log("Server started on port 3000");
});