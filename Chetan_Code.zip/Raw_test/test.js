let arr = [
  { id: 1, name: "John" },
  { id: 2, name: "Jane" },
  { id: 3, name: "Bob" },
  { id: 3, name: "Bob" },
  { id: 4, name: "Alice" },
];

let idToRemove = 3;

arr = arr.filter((obj) => obj.id !== idToRemove);

console.log(arr);
