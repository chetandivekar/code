const  express = require("express");
const  todoRouter = express.Router();
const utils = require("../utils/utils")


todoRouter.get("/:title",(req,res)=>{
    const title = req.params.title.toLowerCase()
    return utils.readdata()
    .then((data)=>{
        const todoobj = data.find((todo)=> {
            return todo.title === title
        })
        return res.status(200)
        .json({
            message:"data fetched",
            data : todoobj,
            error:null
        })
    })
   
})




// todoRouter.get("/", (req,res)=>{
//     return utils.readData()
//       .then((data) => {
//         return res.status(200).json({
//           message: "All todos fetched",
//           data: data,
//           error: null,
//         });
//       })
//       .catch((err) => {
//         return res.status(500).json({
//           message: "Error while fetching todos",
//           data: null,
//           error: err,
//         });
//       });
//   })


  todoRouter.post("/todos", (req, res) => {
    return utils.readData()
      .then((data) => {
        const newData = req.body;
        data.push(newData);
        return writeData(data);
      })
      .then(() => {
        return res.status(200).json({
          message: "Data added successfully",
          error: null,
        });
      })
      .catch((err) => {
        return res.status(500).json({
          message: "Error while adding data",
          error: err,
        });
      });
  });



module.exports = {
    todoRouter,
    a:10
}