let data = fetch('https://fakestoreapi.com/products');
data.then((data)=>{
    return data.json();
}).then((actualdata)=>{
    console.log(actualdata);
    let str = "";
    for(let i in actualdata){
        
        let card = document.querySelector(".card-list");
         str+= `<div class="car-list">
         <div class="cards">
        <div class="img">
          <img
            src="${actualdata[i].image}"
          />
        </div>
        <div class="title">
          ${actualdata[i].title}
        </div>
        <div class="category">electronics</div>
        <div class="description">
          ${actualdata[i].description}
        </div>
        <div class="price">${actualdata[i].price}</div>
      </div>
      </div>`
      card.innerHTML = str
    }
})