
let k=3;
function n_raised_to_m(n,m){
    let res = 1;
    for(let i=0; i<m; i++){
        res*=n;
    }
    return res;
}

let ans = n_raised_to_m(7,5)
let result = ans.toLocaleString();
let finalAns = result.length;
console.log(result[finalAns-k])